<?php
// MENGUNCI ZONA WAKTU KE WAKTU INDONESIA BARAT (SURABAYA)
date_default_timezone_set('Asia/Jakarta');
$host = "192.168.137.37";
$dbname = "fingerprint"; // Nama database yang berbeda
$username = "khususfinger";
$password = "MrPr3s!d3nt";

try {
    $pdo_rfid = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8", $username, $password);
    $pdo_rfid->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Koneksi ke database RFID gagal: " . $e->getMessage());
}
?>