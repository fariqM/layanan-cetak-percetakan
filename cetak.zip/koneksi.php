<?php
// MENGUNCI ZONA WAKTU KE WAKTU INDONESIA BARAT (SURABAYA)
date_default_timezone_set('Asia/Jakarta');
$host = "localhost";
$dbname = "id_card"; // Sesuaikan dengan nama database Anda
$username = "root";
$password = ""; // Kosongkan jika menggunakan XAMPP default

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8", $username, $password);
    // Set mode error PDO ke Exception agar mudah proses debugging
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Koneksi database gagal: " . $e->getMessage());
}
?>